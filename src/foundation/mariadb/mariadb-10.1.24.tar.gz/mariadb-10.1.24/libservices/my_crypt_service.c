#include <service_versions.h>
SERVICE_VERSION my_crypt_service= (void*)VERSION_my_crypt;
